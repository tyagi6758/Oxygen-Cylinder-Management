package com.herostudio.oxygenmanagementsystem.model.DTO;

public class LoginResponse {
    private String email;
    private String privilege;

    public LoginResponse(String email, String privilege) {
        this.email = email;
        this.privilege = privilege;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPrivilege() {
        return privilege;
    }

    public void setPrivilege(String privilege) {
        this.privilege = privilege;
    }
}
