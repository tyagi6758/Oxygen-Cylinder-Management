package com.herostudio.oxygenmanagementsystem.controller;

import com.herostudio.oxygenmanagementsystem.exception.NullObjectException;
import com.herostudio.oxygenmanagementsystem.model.BookCylinder;
import com.herostudio.oxygenmanagementsystem.service.BookCylinderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200/")
@RequestMapping("/book")
public class BookController {
    @Autowired
    private BookCylinderService cylinderService;

    @GetMapping("/")
    public String bookCylinder(@RequestHeader("userId") int userId, @RequestHeader("cylinderId") int cylinderId, @RequestHeader("centerId") int centerId){
        return cylinderService.bookCylinder(userId, cylinderId, centerId);
    }

    @GetMapping("/{userId}")
    public List<BookCylinder> getAllBooksByUserId(@PathVariable("userId") int id){
            return cylinderService.getAllUserBy(id);
    }
}
