package com.herostudio.oxygenmanagementsystem.repository;

import com.herostudio.oxygenmanagementsystem.model.BookCylinder;
import com.herostudio.oxygenmanagementsystem.model.Cylinder;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BookCylinderRepo extends JpaRepository<BookCylinder, Integer> {
    List<BookCylinder> findByUserId(int id);
}
