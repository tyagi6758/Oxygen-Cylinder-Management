package com.herostudio.oxygenmanagementsystem.controller;

import com.herostudio.oxygenmanagementsystem.exception.NullObjectException;
import com.herostudio.oxygenmanagementsystem.model.Center;
import com.herostudio.oxygenmanagementsystem.service.CenterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200/")
@RequestMapping("/center")
public class CenterController {
    @Autowired
    private CenterService service;

    @GetMapping("/{id}")
    public Center getCenter(@PathVariable("id") int id){
        if(service.getById(id).isPresent()){
            return service.getById(id).get();
        }

        throw new NullObjectException("Center not found!");
    }

    @GetMapping("/")
    public List<Center> getAllCenter(){
        return service.getAll();
    }

    @PostMapping("/")
    public Center addNewCenter(@RequestBody Center center){
        return service.addCenter(center);
    }

    @PutMapping("/")
    public Center editCenter(@RequestBody Center center){
        return service.editCenter(center);
    }

    @DeleteMapping("/{id}")
    public String deleteCenter(@PathVariable("id") int id){
        service.delete(id);
        return "Deleted successfully!";
    }
}
