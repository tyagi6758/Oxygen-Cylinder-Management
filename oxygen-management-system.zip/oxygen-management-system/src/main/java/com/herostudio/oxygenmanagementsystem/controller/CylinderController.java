package com.herostudio.oxygenmanagementsystem.controller;

import com.herostudio.oxygenmanagementsystem.model.Center;
import com.herostudio.oxygenmanagementsystem.model.Cylinder;
import com.herostudio.oxygenmanagementsystem.service.CylinderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200/")
@RequestMapping("/cylinder")
public class CylinderController {
    @Autowired
    private CylinderService cylinderService;

    @GetMapping("/{centerId}")
    public List<Cylinder> getAllCylinderByCenterId(@PathVariable("centerId") int id){
        return cylinderService.getAll(id);
    }

    @GetMapping("/city/{city}")
    public List<Cylinder> getAllCylinderByCity(@PathVariable("city") String city){
        return cylinderService.getByCity(city);
    }
    @GetMapping("/")
    public List<Cylinder> getAllCylinder(){
        return cylinderService.getAll();
    }

    @PostMapping("/{centerId}")
    public Cylinder addCylinder(@RequestBody Cylinder cylinder, @PathVariable("centerId") int id) {
        return cylinderService.add(cylinder, id);
    }

    @PutMapping("/{id}")
    public Cylinder editCylinder(@RequestBody Cylinder cylinder, @PathVariable("id") int id){
        return cylinderService.editCylinder(cylinder, id);
    }

    @DeleteMapping("/{id}/center/{centerId}")
    public String deleteCylinder(@PathVariable("id") int id, @PathVariable("centerId") int centerId){
        cylinderService.deleteCylinder(centerId, id);
        return "deleted successfully";
    }
}
