package com.herostudio.oxygenmanagementsystem.service;

import com.herostudio.oxygenmanagementsystem.exception.NullObjectException;
import com.herostudio.oxygenmanagementsystem.model.Center;
import com.herostudio.oxygenmanagementsystem.model.Cylinder;
import com.herostudio.oxygenmanagementsystem.repository.CenterRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CenterService {
    @Autowired
    private CenterRepo centerRepo;
    @Autowired
    private CylinderService service;

    public List<Center> getAll(){
        return centerRepo.findAll();
    }

    public Optional<Center> getById(int id){
        return centerRepo.findByCenterId(id);
    }

    public Center addCenter(Center center) {
        return centerRepo.save(center);
    }

    public Center editCenter(Center center) {
        int id = center.getCenterId();
        if(getById(id).isPresent()){
            return centerRepo.save(center);
        } else {
            throw new NullObjectException("Center id not found!");
        }
    }

    public void delete(int id) {
        if(getById(id).isPresent()) {
            List<Cylinder> cylinders = getById(id).get().getCylinders();
            cylinders.stream().forEach(c -> service.deleteCylinder(id, c.getId()));
            centerRepo.delete(getById(id).get());
        }
    }

    public List<Center> getByCity(String city) {
        return centerRepo.findByCity(city);
    }
}
