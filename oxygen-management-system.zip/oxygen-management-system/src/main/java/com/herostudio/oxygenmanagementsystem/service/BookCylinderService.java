package com.herostudio.oxygenmanagementsystem.service;

import com.herostudio.oxygenmanagementsystem.model.BookCylinder;
import com.herostudio.oxygenmanagementsystem.model.Cylinder;
import com.herostudio.oxygenmanagementsystem.repository.BookCylinderRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Service
public class BookCylinderService {
    @Autowired
    private BookCylinderRepo cylinderRepo;
    @Autowired
    private CylinderService service;
    public String bookCylinder(int userId, int cylinderId, int centerId){
        Cylinder cylinder = null;
        if(service.getById(cylinderId).isPresent()) {
            cylinder = service.getById(cylinderId).get();
            if(cylinder.getQuantity() > 0) {
                cylinder.setQuantity(cylinder.getQuantity() - 1);
                service.editCylinder(cylinder, centerId);
                cylinderRepo.save(new BookCylinder(userId, cylinderId));
            } else {
                return "Out of Stock!";
            }
        } else {
            return "Failed! refresh and try again";
        }
        return "Added Successfully!";
    }

    public List<BookCylinder> getAllUserBy(int id){
        return cylinderRepo.findByUserId(id);
    }
}
