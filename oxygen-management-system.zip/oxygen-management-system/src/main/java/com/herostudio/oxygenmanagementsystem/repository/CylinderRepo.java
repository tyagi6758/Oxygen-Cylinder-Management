package com.herostudio.oxygenmanagementsystem.repository;

import com.herostudio.oxygenmanagementsystem.model.Center;
import com.herostudio.oxygenmanagementsystem.model.Cylinder;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CylinderRepo extends JpaRepository<Cylinder, Integer> {
    List<Cylinder> findByCenter(Center center);
}
