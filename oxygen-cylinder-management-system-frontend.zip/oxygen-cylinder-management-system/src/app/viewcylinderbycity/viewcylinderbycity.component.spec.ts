import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewcylinderbycityComponent } from './viewcylinderbycity.component';

describe('ViewcylinderbycityComponent', () => {
  let component: ViewcylinderbycityComponent;
  let fixture: ComponentFixture<ViewcylinderbycityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewcylinderbycityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewcylinderbycityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
