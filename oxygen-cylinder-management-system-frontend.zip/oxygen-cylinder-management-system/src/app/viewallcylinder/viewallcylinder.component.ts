import { Component, OnInit } from '@angular/core';
import { CylinderService } from '../addcylinder/Cylinder.service';
import { Cylinderconsignment } from "../cylinderconsignment";
@Component({
  selector: 'app-viewallcylinder',
  templateUrl: './viewallcylinder.component.html',
  styleUrls: ['./viewallcylinder.component.css']
})
export class ViewallcylinderComponent implements OnInit {
 
  searchedCylinder: string;
  viewcylinder:Cylinderconsignment[]=null;
  constructor(private service: CylinderService) {
    this.service.getAllCylinder().subscribe(data => {
      this.viewcylinder = data;
    });
   }


  ngOnInit() {
  }

}


