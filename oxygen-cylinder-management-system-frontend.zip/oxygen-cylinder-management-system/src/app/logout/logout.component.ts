import { Component, OnInit } from '@angular/core';
import { AuthService } from '../shared/auth.service';
import { Router,ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {

  constructor(private authservice : AuthService,private router: Router, private activatedRoute:ActivatedRoute) { }

  ngOnInit() {
  }
  logout() {
    // this.authservice.logoutauth();
    this.router.navigateByUrl('/login');
  }

}
