import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cylinder-cart',
  templateUrl: './cylinder-cart.component.html',
  styleUrls: ['./cylinder-cart.component.css']
})
export class CylinderCartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
