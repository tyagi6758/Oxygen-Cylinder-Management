import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CylinderCartComponent } from './cylinder-cart.component';

describe('CylinderCartComponent', () => {
  let component: CylinderCartComponent;
  let fixture: ComponentFixture<CylinderCartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CylinderCartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CylinderCartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
