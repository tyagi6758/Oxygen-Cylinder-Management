import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup,Validators} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../shared/auth.service';


@Component({
  selector: 'app-userviewcylinderbyid',
  templateUrl: './userviewcylinderbyid.component.html',
  styleUrls: ['./userviewcylinderbyid.component.css']
})
export class UserviewcylinderbyidComponent implements OnInit {
  title="view Now";
  public userviewcylinderbyidForm:FormGroup;
  
  msg:string='';
  success:boolean=false;
  redirect:boolean=false;
    constructor(private service:AuthService,private route:Router,private activatedRoute:ActivatedRoute) { }
  
    ngOnInit() :void {
      this.userviewcylinderbyidForm=new FormGroup({
      //  cylinderid: new FormControl('',[Validators.required,Validators.pattern('[0-9]|1[0-9]|2[0-4]')]),
        
      });
    }
  
    addingcylinder(){
      console.warn(this.userviewcylinderbyidForm.value);
    }  
    // get cylinderid(){
    //   return this.userviewcylinderbyidForm.get('cylinderid');
    // }
   
    
    onSubmit() {
      this.route.navigate(["/ordercylinder"]);
    
  
  
  }
  }
  