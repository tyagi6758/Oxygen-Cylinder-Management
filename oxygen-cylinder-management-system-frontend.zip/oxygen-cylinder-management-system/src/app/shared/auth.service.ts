import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { User } from '../register/user';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  logout() {
    throw new Error('Method not implemented.');
  }
 
  constructor() { }

  public validateUser(email:string, password:string)
  {
    if(email=="rounak@gmail.com" && password=="123456"){
      localStorage.setItem('email','rounak@gmail.com');
      return true
    }
    else{
      return false;
    }
  }
   public logoutauth(){
     localStorage.removeItem('ACCESS_TOKEN');
   }
 }
