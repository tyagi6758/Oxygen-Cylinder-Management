import { Center } from "./center";
export class Cylinderconsignment {
    constructor(
        public id: number,
        public pricePerCylinder: number,
        public quantity: number,
        public type: string,
        public weight: number,
        public center: Center,
       
        
    ){}
}
