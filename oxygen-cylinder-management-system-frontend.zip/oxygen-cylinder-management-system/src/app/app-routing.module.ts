import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { CylinderCartComponent } from './cylinder-cart/cylinder-cart.component';
import { ViewBookingComponent } from './view-booking/view-booking.component';

import { AuthGuard } from './shared/auth.guard';
import { OrderComponent } from './order/order.component';
import { CylinderdataComponent } from './cylinderdata/cylinderdata.component';
 import { AddcylinderComponent } from './addcylinder/addcylinder.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { AddcenterComponent } from './addcenter/addcenter.component';
import { ViewallcenterComponent } from './viewallcenter/viewallcenter.component';
import { ViewallcylinderComponent } from './viewallcylinder/viewallcylinder.component';
import { UserhomeComponent } from './userhome/userhome.component';
import { OrdercylinderComponent } from './ordercylinder/ordercylinder.component';
import { UpdatecenterComponent } from './updatecenter/updatecenter.component';
import { UpdatecylinderComponent } from './updatecylinder/updatecylinder.component';
import { HeadertwoComponent } from './headertwo/headertwo.component';
import { ViewcenterbyidComponent } from './viewcenterbyid/viewcenterbyid.component';
import { ViewcylinderbyidComponent } from './viewcylinderbyid/viewcylinderbyid.component';
import { ViewcylinderbycityComponent } from './viewcylinderbycity/viewcylinderbycity.component';
import { UserviewcylinderbyidComponent } from './userviewcylinderbyid/userviewcylinderbyid.component';
import { DeletecenterComponent } from './deletecenter/deletecenter.component';
import { DeletecylinderComponent } from './deletecylinder/deletecylinder.component';






const routes: Routes = [
  { path: '',  component: HomeComponent},
  { path: 'register', component: RegisterComponent },
  {path: 'home',component: HomeComponent },
  {path: 'login',component: LoginComponent },
  { path: 'logout', component: LogoutComponent },
  { path: 'cart', component: CylinderCartComponent },
  { path: 'viewBooking', component: ViewBookingComponent },
  { path: 'Order', component: OrderComponent },
  { path: 'cylinderdata', component: CylinderdataComponent },
   {path:'addcylinder',component:AddcylinderComponent},
  {path:'adminhome',component:AdminhomeComponent},
  {path:'addcenter',component:AddcenterComponent},
  {path:'viewallcenter',component:ViewallcenterComponent},
  {path:'viewallcylinder',component:ViewallcylinderComponent},
  {path:'userhome',component:UserhomeComponent},
  {path:'ordercylinder',component:OrdercylinderComponent},
  {path:'updatecenter/:id',component:UpdatecenterComponent},
   {path:'updatecylinder/:id',component:UpdatecylinderComponent},
   {path:'headertwo',component:HeadertwoComponent},
   {path:'viewcylinderbyid',component:ViewcylinderbyidComponent},
   {path:'viewcenterbyid',component:ViewcenterbyidComponent},
   {path:'viewcylinderbycity',component:ViewcylinderbycityComponent},
   {path:'userviewcylinderbyid',component:UserviewcylinderbyidComponent},
   {path:'deletecenter/:id',component:DeletecenterComponent},
   {path:'deletecylinder/:id/:centerid',component:DeletecylinderComponent},

  // canActivate:[AuthGuard]
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }



