import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup,Validators} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../shared/auth.service';
import { Cylinderconsignment } from "../cylinderconsignment";
import { Center } from "../center";
import { CenterService } from '../addcenter/Center.service';


@Component({
  selector: 'app-updatecenter',
  templateUrl: './updatecenter.component.html',
  styleUrls: ['./updatecenter.component.css']
})
export class UpdatecenterComponent implements OnInit {
  title="updating center";
  public updatecenterForm:FormGroup;
  
  message:string='';
  success:boolean=false;
  
  redirect:boolean=false;
  centerId:number;

  editcenter: Center[] = [];
  center: Center = new Center(0,'','','','','');
    constructor(private service:AuthService,private route:Router,private activatedRoute:ActivatedRoute,private updateservice: CenterService) { }
  
    ngOnInit():void {
      this.updatecenterForm = new FormGroup({
        centerName: new FormControl(''),
        address: new FormControl(''),
        city: new FormControl(''),
        state: new FormControl(''),
        pincode: new FormControl(''),
      });
      let centerId: number = 0;
      this.activatedRoute.params.subscribe(data => {
        centerId = data.id;
        this.updateservice.getCategory(centerId).subscribe(response => {
          console.log(response);
          this.center = response;
  
        });
        
      });
    }
  
  // get centerid(){
  //   return this.updatecenterForm.get('centerid');
  // }
  get centerName(){
    return this.updatecenterForm.get('centerName');
  }
  get address(){
    return this.updatecenterForm.get('address');
  }
  get city(){
    return this.updatecenterForm.get('city');
  }
  get state(){
    return this.updatecenterForm.get('state');
  }
  
  get pincode(){
    return this.updatecenterForm.get('pincode');
  }e
  
  onUpdate() {
 
    console.log(this.center);
    this.updateservice.updateCenter(this.center).subscribe(data => {
      console.log('response',data);
      if(data) {
        this.success = true;
        this.message = "Product updated successfully";
        
      }
      else {
        this.success = false;
        this.message = "Problem updating data";
      }
      //this.router.navigateByUrl("/products/viewAll");

    })
    alert("Update Center...");
    this.route.navigate(["/viewallcenter"]);
  
  
  }
  }