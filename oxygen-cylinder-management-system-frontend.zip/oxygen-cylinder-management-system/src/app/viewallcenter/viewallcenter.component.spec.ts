import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewallcenterComponent } from './viewallcenter.component';

describe('ViewallcenterComponent', () => {
  let component: ViewallcenterComponent;
  let fixture: ComponentFixture<ViewallcenterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewallcenterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewallcenterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
