import { Component, OnInit } from '@angular/core';
import { CenterService } from '../addcenter/Center.service';
import { Center } from '../center';

import { Ng2SearchPipeModule } from 'ng2-search-filter';
@Component({
  selector: 'app-viewallcenter',
  templateUrl: './viewallcenter.component.html',
  styleUrls: ['./viewallcenter.component.css']
})
export class ViewallcenterComponent implements OnInit {
  searchedKeyword: string;
  viewcenters:Center[]=null;
  constructor(private service: CenterService) {
    this.service.getAllCenters().subscribe(data => {
      this.viewcenters = data;
    });
   }

  ngOnInit() {
  }

}
