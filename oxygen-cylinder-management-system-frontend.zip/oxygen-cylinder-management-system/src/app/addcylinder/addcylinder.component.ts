import { Component, OnInit } from '@angular/core';

import { FormControl, FormGroup,Validators} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../shared/auth.service';
import { Cylinderconsignment } from "../cylinderconsignment";
import { Center } from "../center";
import { CylinderService } from './Cylinder.service';

@Component({
  selector: 'app-addcylinder',
  templateUrl: './addcylinder.component.html',
  styleUrls: ['./addcylinder.component.css']
})
export class AddcylinderComponent implements OnInit {

  cylinder: Cylinderconsignment= new Cylinderconsignment(0,0,0,'',0,new Center(0,'','','','',''));
  message: string = '';
  success: boolean = false;
  public addcylinderForm:FormGroup;
  centers: Center[] = [];
  constructor(private service:AuthService,private route:Router,private activatedRoute:ActivatedRoute,private cylindersevice:CylinderService) { }


  ngOnInit() {
    this.addcylinderForm = new FormGroup({
      type: new FormControl('',[Validators.required,Validators.pattern('[a-zA-Z]+$')]),
      center: new FormControl('',Validators.required),
      weight: new FormControl('',[Validators.required,Validators.pattern('[0-9]|1[0-9]|2[0-4]')]),
      quantity: new FormControl('',[Validators.required,Validators.pattern('[0-9]|1[0-9]|2[0-4]')]),
      pricePerCylinder: new FormControl('',[Validators.required,Validators.pattern('[0-9]|1[0-9]|2[0-4]')]),

    });
    this.cylindersevice.getAllCenters().subscribe(data => {
      console.log(data);
      this.centers = data;
    });
  }

  get type(){
    return this.addcylinderForm.get('cylindertype');
  }
  get center(){
    return this.addcylinderForm.get('center');
  }
  get weight(){
    return this.addcylinderForm.get('weight');
  }
  get quantity(){
    return this.addcylinderForm.get('quantity');
  }
  get pricePerCylinder(){
    return this.addcylinderForm.get('pricePerCylinder');
  }


  onSubmit() {
  
    let centerName: string = this.cylinder.center.centerName;
    this.centers.forEach(center => {
      if(center.centerName === centerName) {
        this.cylinder.center.centerId = center.centerId;
      }
    });

    console.log(this.cylinder);
    // alert("Added");
    this.cylindersevice.addcylinder(this.cylinder).subscribe(data => {
      console.log('response',data);
      if(data) {
        this.success = true;
        this.message = "cylinder added successfully";
        
      }
      else {
        this.success = false;
        this.message = "Problem adding data";
      }

      this.cylinder = new Cylinderconsignment(0,0,0,"",0,new Center(0,'','','','',''));
      this.route.navigateByUrl("/viewallcylinder");

    })
    
  
  
  }

}

