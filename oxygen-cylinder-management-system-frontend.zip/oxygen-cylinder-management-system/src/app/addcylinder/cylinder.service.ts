import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Cylinderconsignment } from "../cylinderconsignment";
import { Center } from "../center";
import { AddcylinderComponent } from './addcylinder.component';

@Injectable({
  providedIn: 'root'
})
export class CylinderService {

  constructor(private _httpClient: HttpClient) { }

  getAllCenters():Observable<Center[]> {
    let url = "http://localhost:9090/center/";
    return this._httpClient.get<Center[]>(url).pipe(map(response => response));
  }
  // +cylinder.center.centerId+"/cylinder"
  addcylinder(cylinder:Cylinderconsignment): Observable<Cylinderconsignment> {
    let url = "http://localhost:9090/cylinder/"+cylinder.center.centerId;
    console.log(url);
    return this._httpClient.post<Cylinderconsignment>(url, cylinder);   
    
     
  }
  getAllCylinder(): Observable<Cylinderconsignment[]> {
    let url = "http://localhost:9090/cylinder/";
    console.log(url);
    return this._httpClient.get<Cylinderconsignment[]>(url).pipe(map(response => response));
  }
 
  getCylinder(id: number): Observable<Cylinderconsignment> {
    let url = "http://localhost:9090/cylinder/";
    return this._httpClient.get<Cylinderconsignment>(url).pipe(map(response => response));
  }


  updateCylinder(cylinder:Cylinderconsignment): Observable<Cylinderconsignment> {
    let url = "http://localhost:9090/cylinder/"+cylinder.id;
    console.log(url);
    return this._httpClient.put<Cylinderconsignment>(url, cylinder);   
     
  }
  deleteProduct(id: number,centerid:number): Observable<boolean> {
    let url = "http://localhost:9090/cylinder/"+id+"/center/"+centerid;
    console.log(url);
    let returnVal: Observable<boolean> =  this._httpClient.delete<boolean>(url);  
    return returnVal; 
     
  }

  

}
