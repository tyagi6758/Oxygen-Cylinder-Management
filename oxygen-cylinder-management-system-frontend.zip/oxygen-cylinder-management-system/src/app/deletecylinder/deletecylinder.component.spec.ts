import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeletecylinderComponent } from './deletecylinder.component';

describe('DeletecylinderComponent', () => {
  let component: DeletecylinderComponent;
  let fixture: ComponentFixture<DeletecylinderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeletecylinderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeletecylinderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
