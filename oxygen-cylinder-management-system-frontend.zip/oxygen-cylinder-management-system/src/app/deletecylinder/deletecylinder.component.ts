import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CylinderService } from '../addcylinder/Cylinder.service';
import { Center } from '../center';
import { Cylinderconsignment } from '../cylinderconsignment';

@Component({
  selector: 'app-deletecylinder',
  templateUrl: './deletecylinder.component.html',
  styleUrls: ['./deletecylinder.component.css']
})
export class DeletecylinderComponent implements OnInit {

  message: String = "";
  centers: Center[] = [];
  constructor(private cylindersevice:CylinderService, private activatedRoute: ActivatedRoute, private router: Router) { }
  cylinder: Cylinderconsignment= new Cylinderconsignment(0,0,0,'',0,new Center(0,'','','','',''));

  ngOnInit() {


    let id: number = 0; 
    let centerid: number = 0; 
   

    this.activatedRoute.params.subscribe(data => {
      id = data.id;
      centerid = data.centerid;
     
      console.log(id);
      console.log(centerid);
      this.cylindersevice.deleteProduct(id,centerid).subscribe(response => {
        console.log(response);
        let isDeleted: boolean = response;
        console.log(isDeleted);
        if(isDeleted) {
          this.message = "Cylinder deleted successfully!!!";
        } else {
          this.message = "Unknown error occured";
        }
        alert("Delete Cylinder...");
        this.router.navigateByUrl("/viewcylinder");
      });
    }); 
  
  }
  

}
