import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatecylinderComponent } from './updatecylinder.component';

describe('UpdatecylinderComponent', () => {
  let component: UpdatecylinderComponent;
  let fixture: ComponentFixture<UpdatecylinderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdatecylinderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdatecylinderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
