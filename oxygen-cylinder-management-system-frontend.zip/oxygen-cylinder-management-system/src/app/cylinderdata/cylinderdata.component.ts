import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cylinderdata',
  templateUrl: './cylinderdata.component.html',
  styleUrls: ['./cylinderdata.component.css']
})
export class CylinderdataComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
