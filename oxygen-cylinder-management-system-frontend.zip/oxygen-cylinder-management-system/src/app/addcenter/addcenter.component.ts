import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup,Validators} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../shared/auth.service';
import { CenterService } from './Center.service';
import { Center } from "../center";

@Component({
  selector: 'app-addcenter',
  templateUrl: './addcenter.component.html',
  styleUrls: ['./addcenter.component.css']
})
export class AddcenterComponent implements OnInit {

  center: Center= new Center(0,"","","","",'');
  message: string = '';
  success: boolean = false;
  title="adding center";
public addcenterForm:FormGroup;

redirect:boolean=false;
  constructor(private service:AuthService,private route:Router,private activatedRoute:ActivatedRoute ,private centersevice:CenterService) { }

  ngOnInit():void {
    this.addcenterForm = new FormGroup({
      // centerid: new FormControl('',[Validators.required,Validators.pattern('[0-9]|1[0-9]|2[0-4]')]),
      centerName: new FormControl('',[Validators.required,Validators.minLength(3),Validators.pattern('[a-zA-Z]+$')]),
      address: new FormControl('',[Validators.required,Validators.pattern('[a-zA-Z]+$')]),
      city: new FormControl('',[Validators.required,Validators.pattern('[a-zA-Z]+$')]),
      state: new FormControl('',[Validators.required,Validators.pattern('[a-zA-Z]+$')]),
      pincode: new FormControl('',[Validators.required,Validators.pattern('[0-9]|1[0-9]|2[0-4]')]),
    });
  }
 
// get centerid(){
//   return this.addcenterForm.get('centerid');
// }
get centerName(){
  return this.addcenterForm.get('centerName');
}
get address(){
  return this.addcenterForm.get('address');
}
get city(){
  return this.addcenterForm.get('city');
}
get state(){
  return this.addcenterForm.get('state');
}

get pincode(){
  return this.addcenterForm.get('pincode');
}

onSubmit() {
  console.log(this.center);
  // alert("Added");
  this.centersevice.addcenter(this.center).subscribe(data => {
    console.log('response',data);
    if(data) {
      this.success = true;
      this.message = "center added successfully";
      
    }
    else {
      this.success = false;
      this.message = "Problem adding data";
    }

    this.center = new Center(0,'','','','','');
    this.route.navigateByUrl("/viewallcenter");
  })

}
}