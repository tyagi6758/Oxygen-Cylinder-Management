import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup,Validators} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../shared/auth.service';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css'],
  providers:[AuthService]
})
export class OrderComponent implements OnInit {
title="Order Now";
public orderForm:FormGroup;

msg:string='';
success:boolean=false;

redirect:boolean=false;
  constructor(private service:AuthService,private route:Router,private activatedRoute:ActivatedRoute) { }

  ngOnInit():void {
    this.orderForm = new FormGroup({
      name: new FormControl('',[Validators.required,Validators.minLength(3),Validators.pattern('[a-zA-Z]+$')]),
      email: new FormControl('',[Validators.required,Validators.email]),
      phone: new FormControl('',[Validators.required,Validators.minLength(10),Validators.pattern('[0-9]|1[0-9]|2[0-4]')]),
      city: new FormControl('',[Validators.required,Validators.pattern('[a-zA-Z]+$')]),
      state: new FormControl('',[Validators.required,Validators.pattern('[a-zA-Z]+$')]),
      address: new FormControl('',[Validators.required,Validators.pattern('[a-zA-Z]+$')]),
      pincode: new FormControl('',[Validators.required,Validators.pattern('[0-9]|1[0-9]|2[0-4]')]),
    });
  }
userOrder(){
  console.warn(this.orderForm.value);
}  
get name(){
  return this.orderForm.get('name');
}
get email(){
  return this.orderForm.get('email');
}
get phone(){
  return this.orderForm.get('phone');
}
get city(){
  return this.orderForm.get('city');
}
get state(){
  return this.orderForm.get('state');
}
get address(){
  return this.orderForm.get('address');
}
get pincode(){
  return this.orderForm.get('pincode');
}

onSubmit() {
  this.route.navigate(["/cart"]);


}
}