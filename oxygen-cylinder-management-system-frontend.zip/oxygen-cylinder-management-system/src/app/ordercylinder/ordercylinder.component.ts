import { Component, OnInit } from '@angular/core';
import { CenterService } from '../addcenter/Center.service';
import { CylinderService } from '../addcylinder/Cylinder.service';
import { Center } from '../center';

import { Cylinderconsignment } from '../cylinderconsignment';
import { Login } from '../login/login';
import { Order } from '../order/order';

@Component({
  selector: 'app-ordercylinder',
  templateUrl: './ordercylinder.component.html',
  styleUrls: ['./ordercylinder.component.css']
})
export class OrdercylinderComponent implements OnInit {




toggleShow() {

setTimeout(function(){
  alert("Order Cylinder Successfully."); 
}, 1000);//wait 2 seconds
}

   searchedCylinder: string;
   ordercylinder:Cylinderconsignment[]=null;
   login:Login[]=null;
  //  order: Order=new Order(0,new Cylinderconsignment(0,0,0,'',0,new Center(0,'','','','','')), new Login('',''));
  constructor(private service: CylinderService) {
    this.service.getAllCylinder().subscribe(data => {
      this.ordercylinder = data;
    });
   }


  ngOnInit() {
  

  }

}
